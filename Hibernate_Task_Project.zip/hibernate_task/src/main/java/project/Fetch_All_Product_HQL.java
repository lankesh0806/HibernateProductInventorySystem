package project;

import java.util.List;

import javax.persistence.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Fetch_All_Product_HQL {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		
		Query q = manager.createQuery("select p from Product p");
		
		List<Product> li = q.getResultList();
		
		if(li.isEmpty()) {
			System.out.println("PRODUCT NOT FOUND");
		}
		else {
			for (Product p : li) {
				System.out.println("Product Id : "+p.getProductid());
				System.out.println("Product Name : "+p.getProductname());
				System.out.println("Product Category : "+p.getCategory());
				System.out.println("Product Price : "+p.getPrice());
				System.out.println("Product Quantity : "+p.getQuantity());
				System.out.println("Product Status : "+p.getStatus());
				System.out.println();
			}
		}
	}

}
