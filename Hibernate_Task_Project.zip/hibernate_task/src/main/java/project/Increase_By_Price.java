package project;

import java.util.List;
import java.util.Scanner;

import javax.persistence.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Increase_By_Price {
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		// Increase price by 50 for a category(dynamic)

		Query q = manager.createQuery("update Product p set p.price=p.price+50 where p.category=:cat" );
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Category : ");
		String category = sc.next();
		
		q.setParameter("cat", category);
		
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		
	}

}
