package project;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete_Product_Zero_Quantity {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		// Delete products with zero quantity
		
		Query q = manager.createQuery("delete from Product p where p.quantity=0" );
		
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		if(rows == 0) {
			System.out.println("PRODUCT NOT FOUND");
		}
		else {
			System.out.println("PRODUCT DELETED");
		}
				
		
		
	}

}
