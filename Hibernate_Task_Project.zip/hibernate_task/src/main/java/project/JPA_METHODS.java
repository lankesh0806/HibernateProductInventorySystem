package project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JPA_METHODS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		
		// PERSIST METHOD ----- INSERT DATA
		/*
		Product p = new Product();
		
		p.setProductid(5);
		p.setProductname("Java");
		p.setCategory("Books");
		p.setPrice(700d);
		p.setQuantity(20);
		p.setStatus("AVAILABLE");
		
		transaction.begin();
		manager.persist(p);
		transaction.commit();
		*/
		
		Product p = new Product();
		
		p.setProductid(6);
		p.setProductname("Python");
		p.setCategory("Books");
		p.setPrice(900d);
		p.setQuantity(0);
		p.setStatus("AVAILABLE");
		
		transaction.begin();
		manager.persist(p);
		transaction.commit();
		
		
		// FIND METHOD ----- SEARCH DATA
		// search product by ID

		/*
		Product p = manager.find(Product.class, 7);
		
		if(p != null) {
			System.out.println("Product Id : "+p.getProductid());
			System.out.println("Product Name : "+p.getProductname());
			System.out.println("Product Category : "+p.getCategory());
			System.out.println("Product Price : "+p.getPrice());
			System.out.println("Product Quantity : "+p.getQuantity());
			System.out.println("Product Status : "+p.getStatus());
		}
		else {
			System.out.println("Product Not Found...");
		}
		*/
		
		
		// MERGE METHOD ----- UPDATE DATA
		// update product quantity , price based in ID
		/*
		Product p = manager.find(Product.class, 1);
		
		if(p != null) {
			p.setQuantity(50);
			p.setPrice(300d);
			
			transaction.begin();
			manager.merge(p);
			transaction.commit();
		
		}
		else {
			System.out.println("PRODUCT NOT FOUND");
		}
		*/
		
		
		// REMOVE METHOD ------ DELETE DATA
		// delete product by ID
		/*
		Product p = manager.find(Product.class, 5);
		
		if(p != null) {
			transaction.begin();
			manager.remove(p);
			transaction.commit();
		
		}
		else {
			System.out.println("PRODUCT NOT FOUND");
		}
		*/
		
		
		
		
		
		
		
	}

}
