package project;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Fetch_Specific_Product_Based_Product_Name {
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		// Fetch a specific product based on product name(dynamic)

		Query q = manager.createQuery("select p from Product p where p.productname=:prod" );
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product Name : ");
		String productname = sc.next();
		
		q.setParameter("prod", productname);
		
		List<Product> li = q.getResultList();
		
		if(li.isEmpty()) {
			System.out.println("PRODUCT NOT FOUND");
		}
		else {
			for (Product p : li) {
				System.out.println("Product Id : "+p.getProductid());
				System.out.println("Product Name : "+p.getProductname());
				System.out.println("Product Category : "+p.getCategory());
				System.out.println("Product Price : "+p.getPrice());
				System.out.println("Product Quantity : "+p.getQuantity());
				System.out.println("Product Status : "+p.getStatus());
				System.out.println();
			}
		}
	}

}
