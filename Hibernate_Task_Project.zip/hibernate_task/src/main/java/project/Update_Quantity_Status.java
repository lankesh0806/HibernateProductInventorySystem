package project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Update_Quantity_Status {
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		// Mark(update) Product status as OUT_OF_STOCK When quantity becomes 0
		Query q = manager.createQuery("update Product p set p.status='OUT_OF_STOCK' where p.quantity=0");
		
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		if(rows == 0) {
			System.out.println("PRODUCT NOT FOUND");
		}
		else {
			System.out.println("RECORD UPDATED");
		}
		
	
	}

}
